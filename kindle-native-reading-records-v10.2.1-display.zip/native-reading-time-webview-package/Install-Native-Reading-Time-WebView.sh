#!/bin/sh

PKG="/mnt/us/native-reading-time-webview-package"
BASE="/mnt/us/reading-time"
BIN="$BASE/bin"
WAF="$BASE/webview"
APP_ID="com.shen.readingrecords.v101"
OLD_ID="com.shen.readingrecords"
PROBE_ID="com.shen.readingrecords.webviewprobe"
APPREG=""
JOB="native-reading-time"
CONF="/etc/upstart/${JOB}.conf"
INSTALL_LOG="$BASE/install.log"
VIEWER="/mnt/us/documents/阅读记录.sh"
IMPORTER="/mnt/us/documents/导入旧版阅读数据.sh"

toast() { lipc-set-prop com.lab126.system toasterMessage "$1" >/dev/null 2>&1 || true; }
fail() { echo "$(date): ERROR: $1" >> "$INSTALL_LOG"; toast "Installation failed; see install.log"; exit 1; }

stop_waf() {
    target_id="$1"
    lipc-set-prop com.lab126.appmgrd stop "app://$target_id" >/dev/null 2>&1 || true
}

# appmgrd normally owns the WAF lifecycle, but older/broken registrations may
# leave a Mesquite child alive. Kill only processes whose command line contains
# one of this plugin's private application IDs; never kill Mesquite globally.
kill_stale_waf() {
    target_id="$1"
    for proc_dir in /proc/[0-9]*; do
        [ -r "$proc_dir/cmdline" ] || continue
        proc_cmd="$(tr '\000' ' ' < "$proc_dir/cmdline" 2>/dev/null)"
        case "$proc_cmd" in
            *mesquite*"-l $target_id"*)
                kill -TERM "${proc_dir##*/}" >/dev/null 2>&1 || true
                ;;
        esac
    done
}

mkdir -p "$BASE"
echo "$(date): WebView installer entered, uid=$(id -u)" >> "$INSTALL_LOG"
[ "$(id -u)" -eq 0 ] || fail "not running as root; use ;log runme"
[ -x /usr/bin/mesquite ] || fail "Mesquite is not available"
command -v sqlite3 >/dev/null 2>&1 || fail "sqlite3 is not available"
[ -x /sbin/initctl ] || fail "Upstart is not available"

for required in native-reading-time-daemon.sh native-reading-time.conf build-webview-data.sh Launch-Reading-Records.sh Import-Legacy-Data.sh; do
    [ -f "$PKG/$required" ] || fail "missing payload: $required"
done
for required in config.xml index.html style-v1021.css script-v1021.js; do
    [ -f "$PKG/waf/$required" ] || fail "missing WebView payload: $required"
done

for candidate in /var/local/appreg.db /opt/var/local/appreg.db; do
    [ -f "$candidate" ] && { APPREG="$candidate"; break; }
done
[ -n "$APPREG" ] || fail "appreg.db not found"

# v10.1 could leave a paused WebView alive because its exit button only opened
# Home. Stop every historical ID before replacing files or registry rows.
for stale_id in "$APP_ID" "$OLD_ID" "$PROBE_ID"; do
    stop_waf "$stale_id"
done
sleep 1
for stale_id in "$APP_ID" "$OLD_ID" "$PROBE_ID"; do
    kill_stale_waf "$stale_id"
done

# Existing FBInk releases use this exact file. Keep it in place so an upgrade
# automatically carries all history into the WebView release.
if [ ! -f "$BASE/reading-time.tsv" ]; then
    printf 'date\tbook_id\tseconds\ttitle\n' > "$BASE/reading-time.tsv" || fail "cannot create data file"
else
    stamp="$(date +%Y%m%d-%H%M%S)"
    cp "$BASE/reading-time.tsv" "$BASE/reading-time-before-webview-$stamp.tsv" || fail "cannot back up existing data"
fi

mkdir -p "$BIN" "$WAF" "$BASE/webview-backup" || fail "cannot create installation directories"
cp "$APPREG" "$BASE/webview-backup/appreg-before-v10.db" 2>/dev/null || true

/sbin/initctl stop "$JOB" >/dev/null 2>&1 || true
cp "$PKG/native-reading-time-daemon.sh" "$BIN/native-reading-time-daemon.sh.new" || fail "cannot stage daemon"
chmod 755 "$BIN/native-reading-time-daemon.sh.new"
mv "$BIN/native-reading-time-daemon.sh.new" "$BIN/native-reading-time-daemon.sh" || fail "cannot install daemon"
cp "$PKG/build-webview-data.sh" "$BIN/build-webview-data.sh" || fail "cannot install data exporter"
chmod 755 "$BIN/build-webview-data.sh"
cp "$PKG/waf/"* "$WAF/" || fail "cannot install WebView files"
for web_file in "$WAF/"*; do
    [ -f "$web_file" ] && chmod 644 "$web_file"
done
mkdir -p "$WAF/covers" || fail "cannot create cover cache"
chmod 755 "$WAF/covers"
cp "$PKG/Launch-Reading-Records.sh" "$VIEWER" || fail "cannot install launcher"
cp "$PKG/Import-Legacy-Data.sh" "$IMPORTER" || fail "cannot install importer"
chmod 755 "$VIEWER" "$IMPORTER"

ROOT_RW=0
root_ro() {
    if [ "$ROOT_RW" -eq 1 ]; then
        mntroot ro >/dev/null 2>&1 || /usr/sbin/mntroot ro >/dev/null 2>&1 || /sbin/mntroot ro >/dev/null 2>&1 || true
        ROOT_RW=0
    fi
}
trap root_ro EXIT INT TERM HUP
if mntroot rw >/dev/null 2>&1 || /usr/sbin/mntroot rw >/dev/null 2>&1 || /sbin/mntroot rw >/dev/null 2>&1; then ROOT_RW=1; else fail "cannot remount rootfs"; fi
cp "$PKG/native-reading-time.conf" "$CONF.new" || fail "cannot stage Upstart job"
chmod 644 "$CONF.new"
mv "$CONF.new" "$CONF" || fail "cannot install Upstart job"
/sbin/initctl reload-configuration >/dev/null 2>&1 || true
root_ro
trap - EXIT INT TERM HUP

sqlite3 "$APPREG" <<EOF
BEGIN IMMEDIATE;
INSERT OR IGNORE INTO interfaces(interface) VALUES('application');
INSERT OR IGNORE INTO handlerIds(handlerId) VALUES('$APP_ID');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','lipcId','$APP_ID');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','command','/usr/bin/mesquite -l $APP_ID -c file://$WAF/');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','supportedOrientation','U');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','unloadPolicy','unloadOnPause');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','extend-start','Y');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','maxLoadTime','60');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','maxGoTime','60');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','maxPauseTime','10');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','maxUnloadTime','10');
DELETE FROM properties WHERE handlerId='$PROBE_ID';
DELETE FROM handlerIds WHERE handlerId='$PROBE_ID';
DELETE FROM properties WHERE handlerId='$OLD_ID';
DELETE FROM handlerIds WHERE handlerId='$OLD_ID';
COMMIT;
EOF
[ "$?" -eq 0 ] || fail "cannot register WebView application"

"$BIN/build-webview-data.sh" >> "$INSTALL_LOG" 2>&1 || fail "cannot create initial data snapshot"
/sbin/initctl start "$JOB" >/dev/null 2>&1 || true

# Remove only obsolete launch icons. Historical data and old UI assets remain
# untouched so rollback is possible.
rm -f "/mnt/us/documents/阅读记录-WebView测试.sh" "/mnt/us/documents/卸载-WebView界面测试.sh"
lipc-set-prop com.lab126.winmgr eatTapMode 0 >/dev/null 2>&1 || true
lipc-set-prop com.lab126.powerd preventScreenSaver 0 >/dev/null 2>&1 || true
lipc-set-prop com.lab126.scanner doFullScan 1 >/dev/null 2>&1 || lipc-set-prop com.lab126.scanner triggerUpdate 1 >/dev/null 2>&1 || true

echo "$(date): WebView v10.2.1 display refinement installed; existing data preserved" >> "$INSTALL_LOG"
toast "Reading Records v10.2.1 installed"
sync
exit 0
