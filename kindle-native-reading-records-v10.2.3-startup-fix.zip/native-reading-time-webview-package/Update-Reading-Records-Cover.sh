#!/bin/sh

BASE="/mnt/us/reading-time"
COVER_DIR="$BASE/custom-cover"
COVER="$COVER_DIR/reading-records-cover.png"
VIEWER="/mnt/us/documents/阅读记录.sh"
LOG="$BASE/cover-update.log"
TMP="$VIEWER.cover-new"

toast() { lipc-set-prop com.lab126.system toasterMessage "$1" >/dev/null 2>&1 || true; }
fail() { echo "$(date): ERROR: $1" >> "$LOG"; rm -f "$TMP"; toast "$2"; exit 1; }

[ -f "$COVER" ] || fail "custom cover not found" "请放入 reading-records-cover.png"
[ -f "$VIEWER" ] || fail "viewer not found" "未找到阅读记录启动文件"

signature="$(od -An -tx1 -N8 "$COVER" 2>/dev/null | tr -d ' \r\n')"
[ "$signature" = "89504e470d0a1a0a" ] || fail "not a PNG file" "封面必须是 PNG 图片"

size="$(wc -c < "$COVER" 2>/dev/null | tr -d ' ')"
[ -n "$size" ] || fail "cannot read cover size" "无法读取封面"
[ "$size" -le 524288 ] || fail "cover is larger than 512 KB" "封面请控制在 512KB 内"

encode_cover() {
    if command -v base64 >/dev/null 2>&1; then
        base64 "$COVER" | tr -d '\r\n'
    elif command -v openssl >/dev/null 2>&1; then
        openssl base64 -A -in "$COVER"
    else
        return 1
    fi
}

if ! command -v base64 >/dev/null 2>&1 && ! command -v openssl >/dev/null 2>&1; then
    fail "no Base64 encoder" "系统缺少封面转换工具"
fi

{
    printf '#!/bin/sh\n'
    printf '# Icon: data:image/png;base64,'
    encode_cover
    printf '\n'
    tail -n +3 "$VIEWER"
} > "$TMP"

[ "$?" -eq 0 ] || fail "cannot encode cover" "封面转换失败"
chmod 755 "$TMP" || fail "cannot chmod launcher" "封面更新失败"
mv "$TMP" "$VIEWER" || fail "cannot replace launcher" "封面更新失败"
touch "$VIEWER"
sync
lipc-set-prop com.lab126.scanner doFullScan 1 >/dev/null 2>&1 || lipc-set-prop com.lab126.scanner triggerUpdate 1 >/dev/null 2>&1 || true
echo "$(date): custom cover installed from $COVER" >> "$LOG"
toast "阅读记录封面已更新"
exit 0
