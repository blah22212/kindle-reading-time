#!/bin/sh

BASE="/mnt/us/reading-time"
DATA="$BASE/reading-time.tsv"
WAF="$BASE/webview"
OUT="$WAF/data.js"
TMP="$OUT.tmp"
CC_DB="/var/local/cc.db"
CC_COPY="$BASE/.cc-webview.db"
CATALOG="$BASE/.webview-catalog.tsv"
PROGRESS="$BASE/.webview-progress.tsv"
COVER_MAP="$BASE/.webview-covers.tsv"
READ_IDS="$BASE/.webview-read-ids.txt"
COVERS="$WAF/covers"
TAB="$(printf '\t')"

mkdir -p "$WAF" "$COVERS"
chmod 755 "$COVERS" 2>/dev/null || true
[ -f "$DATA" ] || printf 'date\tbook_id\tseconds\ttitle\n' > "$DATA"
rm -f "$CC_COPY" "$CATALOG" "$PROGRESS" "$COVER_MAP" "$READ_IDS"
awk -F '\t' 'NR>1 && $2!="" && $2!="unknown" && !seen[$2]++ { print $2 }' "$DATA" > "$READ_IDS"

# p_cdeKey matches the timer's ID; p_thumbnail points to Kindle's cached cover.
# Query a private snapshot so the Kindle catalog is never held or modified.
if command -v sqlite3 >/dev/null 2>&1 && [ -r "$CC_DB" ] && cp "$CC_DB" "$CC_COPY" 2>/dev/null; then
    sqlite3 -readonly -separator "$TAB" "$CC_COPY" \
        "SELECT replace(replace(replace(COALESCE(p_cdeKey,''),char(9),' '),char(10),' '),char(13),' '), replace(replace(replace(COALESCE(p_titles_0_nominal,''),char(9),' '),char(10),' '),char(13),' '), CASE WHEN p_percentFinished IS NULL THEN '' ELSE CAST(p_percentFinished + 0.5 AS INTEGER) END, replace(replace(replace(COALESCE(p_thumbnail,''),char(9),' '),char(10),' '),char(13),' ') FROM Entries WHERE p_cdeKey IS NOT NULL AND p_titles_0_nominal IS NOT NULL ORDER BY p_lastAccess DESC;" \
        > "$CATALOG" 2>/dev/null || : > "$CATALOG"
fi
rm -f "$CC_COPY"

if [ -s "$CATALOG" ]; then
    awk -F '\t' 'NF>=3 && $2!="" && $3!="" && !seen[$2]++ { print $2 "\t" $3 }' "$CATALOG" > "$PROGRESS"
else
    : > "$PROGRESS"
fi

resolve_thumbnail() {
    candidate="$1"
    case "$candidate" in file://*) candidate="${candidate#file://}" ;; esac
    if [ -f "$candidate" ]; then return 0; fi
    leaf="${candidate##*/}"
    if [ -n "$leaf" ] && [ -f "/mnt/us/system/thumbnails/$leaf" ]; then
        candidate="/mnt/us/system/thumbnails/$leaf"
        return 0
    fi
    candidate=""
    return 1
}

cover_no=0
while IFS="$TAB" read -r cid ctitle cprogress cthumb; do
    [ -n "$cid" ] || continue
    grep -F -x -q "$cid" "$READ_IDS" 2>/dev/null || continue
    candidate=""
    if [ -n "$cthumb" ]; then resolve_thumbnail "$cthumb" || true; fi
    if [ -z "$candidate" ] && [ -d /mnt/us/system/thumbnails ]; then
        candidate="$(find /mnt/us/system/thumbnails -type f 2>/dev/null | grep -iF "$cid" | head -n 1)"
    fi
    [ -n "$candidate" ] && [ -f "$candidate" ] || continue
    cover_no=$((cover_no+1))
    case "${candidate##*.}" in [Pp][Nn][Gg]) ext="png" ;; *) ext="jpg" ;; esac
    local_name="cover-$(printf '%04d' "$cover_no").$ext"
    target="$COVERS/$local_name"
    if [ ! -f "$target" ] || ! cmp -s "$candidate" "$target" 2>/dev/null; then
        cp "$candidate" "$target.tmp" 2>/dev/null && mv "$target.tmp" "$target"
    fi
    [ -f "$target" ] && printf '%s\t%s\n' "$cid" "covers/$local_name" >> "$COVER_MAP"
done < "$CATALOG"

generated="$(date '+%Y-%m-%d %H:%M:%S')"
printf 'window.READING_DATA={generatedAt:"%s",entries:[' "$generated" > "$TMP" || exit 1

awk -F '\t' '
function code(t) { return length(t) >= 16 && t !~ /[^0-9A-Fa-f]/ }
function usable(t,id) { return t != "" && t != "unknown" && t != id && !code(t) }
function esc(s) { gsub(/\\/, "\\\\", s); gsub(/"/, "\\\"", s); gsub(/\r/, "", s); gsub(/\n/, " ", s); return s }
NR > 1 && NF >= 3 && $1 != "" {
    rows++; date[rows]=$1; id[rows]=$2; sec[rows]=$3+0; raw[rows]=$4
    key=(id[rows]=="" || id[rows]=="unknown") ? id[rows] SUBSEP raw[rows] : id[rows]
    rowkey[rows]=key
    if (!(key in title) || (!usable(title[key],id[rows]) && usable(raw[rows],id[rows]))) title[key]=raw[rows]
    bookid[key]=id[rows]
}
END {
    first=1
    for (n=1;n<=rows;n++) {
        name=title[rowkey[n]]
        if (!usable(name,bookid[rowkey[n]])) name=bookid[rowkey[n]]
        if (name=="" || name=="unknown") name="未知书籍"
        printf "%s[\"%s\",\"%s\",%d,\"%s\"]", (first?"":","), esc(date[n]), esc(id[n]), sec[n], esc(name)
        first=0
    }
}' "$DATA" >> "$TMP"

printf '],progress:[' >> "$TMP"
if [ -s "$PROGRESS" ]; then
    awk -F '\t' '
    function esc(s) { gsub(/\\/, "\\\\", s); gsub(/"/, "\\\"", s); gsub(/\r/, "", s); gsub(/\n/, " ", s); return s }
    NF>=2 && !seen[$1]++ { printf "%s[\"%s\",%d]", (first++?",":""), esc($1), $2+0 }
    ' "$PROGRESS" >> "$TMP"
fi

printf '],covers:[' >> "$TMP"
if [ -s "$COVER_MAP" ]; then
    awk -F '\t' '
    function esc(s) { gsub(/\\/, "\\\\", s); gsub(/"/, "\\\"", s); return s }
    NF>=2 && !seen[$1]++ { printf "%s[\"%s\",\"%s\"]", (first++?",":""), esc($1), esc($2) }
    ' "$COVER_MAP" >> "$TMP"
fi
printf ']};\n' >> "$TMP"

rm -f "$CATALOG" "$PROGRESS" "$COVER_MAP" "$READ_IDS"
mv "$TMP" "$OUT" || exit 1
chmod 644 "$OUT" "$COVERS"/* 2>/dev/null || true
exit 0
