#!/bin/sh

BASE="/mnt/us/reading-time"
TARGET="$BASE/reading-time.tsv"
SOURCE="/mnt/us/reading-time-import.tsv"
JOB="native-reading-time"
LOG="$BASE/import.log"
ADD="$BASE/.import-additions.tsv"
MERGED="$BASE/.reading-time-merged.tsv"

toast() { lipc-set-prop com.lab126.system toasterMessage "$1" >/dev/null 2>&1 || true; }
mkdir -p "$BASE"
echo "$(date): legacy import requested" >> "$LOG"

if [ ! -f "$SOURCE" ]; then
    echo "$(date): source missing: $SOURCE" >> "$LOG"
    toast "Put reading-time-import.tsv in Kindle root"
    exit 1
fi
head -1 "$SOURCE" | grep -q '^date[[:space:]]' || { echo "$(date): invalid header" >> "$LOG"; toast "Invalid legacy data file"; exit 1; }
awk -F '\t' 'NR>1 && NF>=3 { if ($1 !~ /^[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]$/ || $3 !~ /^[0-9][0-9]*$/) bad=1 } END { exit bad }' "$SOURCE" || {
    echo "$(date): invalid data row" >> "$LOG"
    toast "Invalid row in legacy data file"
    exit 1
}
[ -f "$TARGET" ] || printf 'date\tbook_id\tseconds\ttitle\n' > "$TARGET"

/sbin/initctl stop "$JOB" >/dev/null 2>&1 || true
stamp="$(date +%Y%m%d-%H%M%S)"
cp "$TARGET" "$BASE/reading-time-before-import-$stamp.tsv" || { /sbin/initctl start "$JOB" >/dev/null 2>&1 || true; toast "Cannot back up current data"; exit 1; }

# Multiset merge: if a row occurs N times in the backup and M times in the
# current file, retain max(N,M). This preserves legitimate repeated sessions
# while importing the same backup twice cannot double the reading time.
awk '
NR==FNR { if (FNR>1) have[$0]++; next }
FNR==1 { next }
{ seen[$0]++; if (seen[$0] > have[$0]) print $0 }
' "$TARGET" "$SOURCE" > "$ADD"

cp "$TARGET" "$MERGED" && cat "$ADD" >> "$MERGED" && mv "$MERGED" "$TARGET"
result=$?
added="$(awk 'END{print NR+0}' "$ADD")"
rm -f "$ADD" "$MERGED"
/sbin/initctl start "$JOB" >/dev/null 2>&1 || true

if [ "$result" -eq 0 ]; then
    "$BASE/bin/build-webview-data.sh" >> "$LOG" 2>&1 || true
    echo "$(date): import complete, added=$added" >> "$LOG"
    toast "Legacy data imported: $added rows added"
    sync
    exit 0
fi
echo "$(date): import failed" >> "$LOG"
toast "Legacy data import failed"
exit 1
